/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthcaresystem412;


public class Controller {
    
    // This is a session user, used for all checks for userIDs, permissions, and other uses
    public static User user;
    
}






